package io.renren.controller;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * @Description:
 * @Author : fys
 * @Date : 2021/7/1
 */
public class test {
    public static void main(String[] args) throws InterruptedException {
        ExecutorService executorService = Executors.newFixedThreadPool(5);
        CountDownLatch countDownLatch=new CountDownLatch(5);
        for (int i = 0; i < 5; i++) {
            int finalI = i;
            executorService.execute( ()->{
                System.out.println(Thread.currentThread().getName()+"-"+finalI);
                countDownLatch.countDown();
            });

        }
        countDownLatch.await();
        System.out.println("end");
    }
}
