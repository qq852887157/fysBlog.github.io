package io.renren.entity;

import java.util.*;

/**
 * @Description:
 * @Author : fys
 * @Date : 2021/7/1
 */
public class TestEntity {
    List<Map<String, List<Map<String, String>>>> list;

    public List<Map<String, List<Map<String, String>>>> getList() {
        return list;
    }

    public void setList(List<Map<String, List<Map<String, String>>>> list) {
        this.list = list;
    }
}
