package com.fys.gulimall.thirdparty;

import com.aliyun.oss.OSSClient;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

@SpringBootTest
class GulimallThirdPartyApplicationTests {
    @Autowired
    OSSClient ossClient;
    @Test
    void contextLoads() {
    }
    @Value("${spring.cloud.alicloud.access-key}")
    public String access_key;
    @Test
    public void testUpload() throws FileNotFoundException {
        // System.out.println(access_key);
        // 上传文件流
        InputStream inputStream=new FileInputStream("/Users/fys666/Downloads/参考.txt");
        ossClient.putObject("fys-upload","as2s.txt",inputStream);
        ossClient.shutdown();
        System.out.println("上传成功");
    }


}
