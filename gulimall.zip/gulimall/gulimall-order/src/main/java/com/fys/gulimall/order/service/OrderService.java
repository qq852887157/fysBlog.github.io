package com.fys.gulimall.order.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.fys.common.utils.PageUtils;
import com.fys.gulimall.order.entity.OrderEntity;

import java.util.Map;

/**
 * 订单
 *
 * @author fys
 * @email fys@gmail.com
 * @date 2021-03-21 20:41:11
 */
public interface OrderService extends IService<OrderEntity> {

    PageUtils queryPage(Map<String, Object> params);
}

