package com.fys.gulimall.order.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.fys.common.utils.PageUtils;
import com.fys.gulimall.order.entity.RefundInfoEntity;

import java.util.Map;

/**
 * 退款信息
 *
 * @author fys
 * @email fys@gmail.com
 * @date 2021-03-21 20:41:11
 */
public interface RefundInfoService extends IService<RefundInfoEntity> {

    PageUtils queryPage(Map<String, Object> params);
}

