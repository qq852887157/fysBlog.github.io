package com.fys.gulimall.product.vo;

import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

/**
 * @Description:
 * @Author : fys
 * @Date : 2021/3/31
 */
@Data
public class AttrRespVo extends AttrVo{
    /**
     * 分类名称
     */
    private String catelogName;
    /**
     * 分组名称
     */
    private String groupName;
    /**
     * 分类数组
     */
    private Long[] catelogPath;
}
