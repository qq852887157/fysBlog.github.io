package com.fys.gulimall.product;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.session.data.redis.config.annotation.web.http.EnableRedisHttpSession;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 *  1、整合Mybatis-plus
 *      1)、导入依赖
 *      <dependency>
 *             <groupId>com.baomidou</groupId>
 *             <artifactId>mybatis-plus-boot-starter</artifactId>
 *             <version>3.2.0</version>
 *         </dependency>
 *      2)、配置
 *          1、配置数据源
 *              导入数据库的驱动
 *              在application.yml配置数据源信息
 *          2、配置mybatis-plus
 *              1、使用@MapperScan
 */
@EnableRedisHttpSession
@EnableCaching
@MapperScan("com.fys.gulimall.product.dao")
@EnableDiscoveryClient
@SpringBootApplication
@EnableTransactionManagement
//开启远程调用功能
@EnableFeignClients(basePackages = "com.fys.gulimall.product.feign")
public class GulimallProductApplication {

    public static void main(String[] args) {
        SpringApplication.run(GulimallProductApplication.class, args);
    }

}
