package com.fys.gulimall.product.config;

import org.springframework.context.annotation.Configuration;

/**
 * @Description:
 * @Author : fys
 * @Date : 2021/4/16
 */
@Configuration
public class MySeataConfig {
}
