package com.fys.gulimall.product.feign;

import com.fys.common.to.SkuHasStockVo;
import com.fys.common.utils.R;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

/**
 * @Description:库存服务
 * @Author : fys
 * @Date : 2021/4/4
 */
@FeignClient("gulimall-ware")
public interface WareFeignService {
    @PostMapping("/ware/waresku/hasstock")
    R getSkuHasStock(@RequestBody List<Long> skuIds);

    @RequestMapping("/delete")
    R delete(@RequestBody Long[] ids);
}
