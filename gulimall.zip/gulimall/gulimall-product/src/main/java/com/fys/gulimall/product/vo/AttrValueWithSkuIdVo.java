package com.fys.gulimall.product.vo;

import lombok.Data;

/**
 * @Description:
 * @Author : fys
 * @Date : 2021/4/13
 */
@Data
public class AttrValueWithSkuIdVo {
    private  String attrValue;
    private String skuIds;
}
