package com.fys.gulimall.product.feign;

import com.fys.common.to.SkuReductionTo;
import com.fys.common.to.SpuBoundTo;
import com.fys.common.utils.R;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * @Description:
 * @Author : fys
 * @Date : 2021/4/3
 */
@FeignClient("gulimall-coupon")
public interface CouponFeignService {
    /**
     * @Author fys
     * @Description CouponfeignService.saveSpuBounds(SpuBoundTo spuBoundTo)
     *                1、@RequestBody 将这个对象转json
     *                2、找到gulimall-coupon服务,给/coupon/spubounds/save发送请求。
     *                将上一步json放到请求体
     *                3、对方服务收到请求。
     *                @RequestBody SpuBoundsEntity spuBounds  ；将请求体的json转为 SpuBoundsEntity
     *
     *                只要json数据属性是一致的 ，双方服务无需使用同一个to
     * @Date 2021/4/3
     * @Param
     * @return
    */
    @PostMapping("/coupon/spubounds/save")
    R saveSpuBounds(@RequestBody SpuBoundTo spuBoundTo);
    @PostMapping("/coupon/skufullreduction/saveinfo")
    R saveSkuReduction(@RequestBody SkuReductionTo skuReductionTo);
}
