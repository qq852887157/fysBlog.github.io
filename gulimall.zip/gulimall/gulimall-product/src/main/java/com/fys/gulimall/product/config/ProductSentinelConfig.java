package com.fys.gulimall.product.config;

import com.alibaba.csp.sentinel.adapter.spring.webflux.callback.BlockRequestHandler;
import com.alibaba.csp.sentinel.adapter.spring.webflux.callback.WebFluxCallbackManager;
import org.springframework.context.annotation.Configuration;

/**
 * @Description:
 * @Author : fys
 * @Date : 2021/4/14
 */
// @Configuration
// public class ProductSentinelConfig {
//     public ProductSentinelConfig(){
//         WebFluxCallbackManager.setBlockHandler(new BlockRequestHandler(){});
//     }
// }
