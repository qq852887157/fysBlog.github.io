package com.fys.gulimall.product.vo;

import lombok.Data;

import java.io.Serializable;

/**
 * @Description:
 * @Author : fys
 * @Date : 2021/4/14
 */
@Data
public class UserLoginVo implements Serializable {
    private String loginacct;
    private String password;
}
