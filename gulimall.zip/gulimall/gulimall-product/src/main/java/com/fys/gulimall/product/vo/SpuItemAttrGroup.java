package com.fys.gulimall.product.vo;

import com.fys.gulimall.product.entity.spu.Attr;
import lombok.Data;
import lombok.ToString;

import java.util.List;

/**
 * @Description:
 * @Author : fys
 * @Date : 2021/4/12
 */
@ToString
@Data
public class SpuItemAttrGroup {
    private String groupName;

    /** 两个属性attrName、attrValue */
    private List<Attr> attrs;
}
