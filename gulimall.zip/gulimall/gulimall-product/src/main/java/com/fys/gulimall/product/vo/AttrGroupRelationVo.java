package com.fys.gulimall.product.vo;

import lombok.Data;

/**
 * @Description:
 * @Author : fys
 * @Date : 2021/3/31
 */
@Data
public class AttrGroupRelationVo {

    private Long attrId;
    private Long attrGroupId;
}
