package com.fys.gulimall.product.config;

import org.redisson.Redisson;
import org.redisson.api.RedissonClient;
import org.redisson.config.Config;
import org.redisson.config.SingleServerConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.data.redis.RedisProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @Description:
 * @Author : fys
 * @Date : 2021/4/5
 */
@Configuration
public class MyRedissonConfig {
    /**
     * @Author fys
     * @Description //TODO 集群
     * @Date 2021/4/5
     * @Param
     * @return
     */
    // @Bean(destroyMethod = "shutdown")
    // RedissonClient redisson(){
    //     Config config = new Config();
    //     config.useClusterServers()
    //             .setScanInterval(2000) // 集群状态扫描间隔时间，单位是毫秒
    //             //可以用"rediss://"来启用SSL连接
    //             .addNodeAddress("redis://127.0.0.1:7000", "redis://127.0.0.1:7001")
    //             .addNodeAddress("redis://127.0.0.1:7002");
    //     return  Redisson.create(config);
    // }


    /**
     * @Author fys
     * @Description //TODO 单机
     * @Date 2021/4/5
     * @Param
     * @return
     */
    private String ipAddr = "127.0.0.1";
    // redission通过redissonClient对象使用 // 如果是多个redis集群，可以配置
    @Bean(destroyMethod = "shutdown")
    public RedissonClient redisson() {
        Config config = new Config();
        // 创建单例模式的配置
        config.useSingleServer().setAddress("redis://" + ipAddr + ":6379").setPassword("ffcsip");
        return Redisson.create(config);
    }


}
