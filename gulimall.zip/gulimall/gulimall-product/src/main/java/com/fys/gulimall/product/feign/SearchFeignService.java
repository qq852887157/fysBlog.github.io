package com.fys.gulimall.product.feign;

import com.fys.common.to.es.SkuEsModel;
import com.fys.common.utils.R;
import com.fys.gulimall.product.feign.fallback.SearchFeignServiceFallBack;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

/**
 * @Description:
 * @Author : fys
 * @Date : 2021/4/5
 */
@FeignClient(value = "gulimall-search" ,fallback = SearchFeignServiceFallBack.class)
public interface SearchFeignService {
    @PostMapping("/search/save/product")
    R productStatusUp(@RequestBody List<SkuEsModel> skuEsModelList);

    @GetMapping("/search/save/productFeignTest")
    String productFeignTest();
}
