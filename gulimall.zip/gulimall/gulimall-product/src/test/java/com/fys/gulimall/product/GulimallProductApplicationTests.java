package com.fys.gulimall.product;

import com.fys.gulimall.product.dao.AttrAttrgroupRelationDao;
import com.fys.gulimall.product.dao.AttrGroupDao;
import com.fys.gulimall.product.service.AttrGroupService;
import com.fys.gulimall.product.service.SkuSaleAttrValueService;
import com.fys.gulimall.product.vo.SkuItemSaleAttrVo;
import com.fys.gulimall.product.vo.SpuItemAttrGroup;
import org.junit.jupiter.api.Test;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.core.StringRedisTemplate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@SpringBootTest
class GulimallProductApplicationTests {
    @Autowired
    RedissonClient redissonClient;
    // StringRedisTemplate stringRedisTemplate;
    @Autowired
    AttrGroupDao attrGroupDao;
    @Autowired
    SkuSaleAttrValueService skuSaleAttrValueService;
    @Autowired
    AttrAttrgroupRelationDao attrAttrgroupRelationDao;
    @Test
    void contextLoads() {
        System.out.println(redissonClient);
    }

    @Test
    public void test(){
        // List<SpuItemAttrGroup> attrGroupWithAttrsBySpuId = attrGroupDao.getAttrGroupWithAttrsBySpuId(15L, 225L);
        List<SkuItemSaleAttrVo> saleAttrsBySpuId = skuSaleAttrValueService.getSaleAttrsBySpuId(25L);
        System.out.println(saleAttrsBySpuId);
    }

    @Test
    public void test2(){
        Map<String, Object> map =new HashMap<>();
        map.put("attr_id",1);
        map.put("attr_group_id",2);
        List list=new ArrayList();
        list.add(map);
        list.add(map);
        attrAttrgroupRelationDao.insertAll2(list);
    }


}
