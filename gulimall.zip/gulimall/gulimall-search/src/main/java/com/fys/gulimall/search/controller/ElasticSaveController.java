package com.fys.gulimall.search.controller;

import com.fys.common.exception.BizCodeEnum;
import com.fys.common.to.es.SkuEsModel;
import com.fys.common.utils.R;
import com.fys.gulimall.search.service.ProductSaveService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @Description:
 * @Author : fys
 * @Date : 2021/4/5
 */
@RequestMapping("/search/save")
@RestController
@Slf4j
public class ElasticSaveController {
    @Autowired
    ProductSaveService productSaveService;
    @PostMapping("/product")
    public R productStatusUp(@RequestBody List<SkuEsModel> skuEsModelList){
        Boolean b=true;
        try {
            //返回true有错误，false无错误
            b=productSaveService.productStatusUp(skuEsModelList);
        }catch (Exception e){
            log.error("es商品上架错误",e);
            return R.error(BizCodeEnum.PRODUCT_UP_EXCEPTION.getCode(),BizCodeEnum.PRODUCT_UP_EXCEPTION.getMsg());
        }
        if(!b){
            return R.ok();
        }else {
            return R.error(BizCodeEnum.PRODUCT_UP_EXCEPTION.getCode(),BizCodeEnum.PRODUCT_UP_EXCEPTION.getMsg());
        }

    }

    @GetMapping("/productFeignTest")
    public String productFeignTest(){
        return "ok";
    }
}
