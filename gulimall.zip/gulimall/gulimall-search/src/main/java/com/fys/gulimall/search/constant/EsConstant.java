package com.fys.gulimall.search.constant;

/**
 * @Description:
 * @Author : fys
 * @Date : 2021/4/5
 */
public class EsConstant {
    /**
     * sku在es的索引
     */
    public static final  String PRODUCT_INDEX="product";
    /**
     * 每页显示多少
     */
    public static final Integer PRODUCT_PAGESIZE=2;

}
