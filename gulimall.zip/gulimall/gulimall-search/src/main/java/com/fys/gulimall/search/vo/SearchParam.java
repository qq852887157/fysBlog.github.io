package com.fys.gulimall.search.vo;

import lombok.Data;
import java.util.*;
/**
 * @Description:检索条件
 * @Author : fys
 * @Date : 2021/4/10
 */
@Data
public class SearchParam {
    /**
     * 页面传递的全文匹配关键字
     */
    private String keyword;
    /**
     * 三级分类的id
     */
    private Long catalog3Id;
    /**
     * 排序条件
     * sort=saleCount_asc/desc 销量
     * sort=skuPrice_asc/desc 价格
     * sort=hotScore_asc/desc 热点
     */
    private String sort;
    /**
     * 是否有货 默认为1有库存,0没有
     */
    private Integer hasStock ;
    /**
     * 价格区间
     */
    private String skuPrice;
    /**
     * 品牌,可以多选
     */
    private List<Long> brandId;
    /**
     * 属性  例如 ios:安卓:6寸
     */
    private List<String> attrs;
    /**
     * 页码
     */
    private Integer pageNum=1;
}
