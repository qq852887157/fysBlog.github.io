package com.fys.gulimall.search.service;

import com.fys.common.to.es.SkuEsModel;

import java.io.IOException;
import java.util.List;

/**
 * @Description:
 * @Author : fys
 * @Date : 2021/4/5
 */

public interface ProductSaveService {
    boolean productStatusUp(List<SkuEsModel> skuEsModelList) throws IOException;
}
