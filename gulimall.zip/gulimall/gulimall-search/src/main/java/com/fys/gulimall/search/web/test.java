package com.fys.gulimall.search.web;

/**
 * @Description:
 * @Author : fys
 * @Date : 2021/4/15
 */
public class test {
    public static void main(String[] args) throws InterruptedException {
        while (true){
            Thread.sleep(1000);
        }
    }
}
