package com.fys.gulimall.search.vo;

import com.fys.common.to.es.SkuEsModel;
import lombok.Data;
import java.util.*;
/**
 * @Description: 查询返回类
 * @Author : fys
 * @Date : 2021/4/10
 */
@Data
public class SearchResult {
    /**
     * 查询到所有商品信息
     */
    private List<SkuEsModel> products;
    /**
     * 当前页码
     */
    private Integer pageNum;
    /**
     * 总记录数
     */
    private Long total;
    /**
     * 总页码
     */
    private Integer totalPages;
    /**
     * 所有导航页
     */
    private List<Integer> pageNavs;
    /**
     * 查询到品牌的所有结果
     */
    private List<BrandVo> brands;
    /**
     * 查询到品牌的所有结果,所涉及到的属性
     */
    private List<AttrVo> attrs;
    /**
     * 查询到品牌的所有结果,所涉及到的分类
     */
    private List<CatalogVo>catalogs;
    /**
     * 品牌vo
     */
    @Data
    public static class BrandVo{
        /**
         * 品牌id
         */
        private Long brandId;
        /**
         * 品牌名称
         */
        private String brandName;
        /**
         * 品牌图片url
         */
        private String brandImg;
    }

    /**
     * 属性vo
     */
    @Data
    public static class AttrVo{
        /**
         * 属性id
         */
        private Long attrId;
        /**
         * 属性名称
         */
        private String attrName;
        /**
         * 属性值
         */
        private List<String> attrValue;
    }

    /**
     * 分类vo
     */
    @Data
    public static class CatalogVo{
        /**
         * 分类id
         */
        private Long catalogId;
        /**
         * 分类名称
         */
        private String catalogName;
    }
}
