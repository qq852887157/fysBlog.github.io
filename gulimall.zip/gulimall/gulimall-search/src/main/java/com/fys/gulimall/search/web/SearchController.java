package com.fys.gulimall.search.web;

import com.fys.gulimall.search.service.MallSearchService;
import com.fys.gulimall.search.vo.SearchParam;
import com.fys.gulimall.search.vo.SearchResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * @Description:
 * @Author : fys
 * @Date : 2021/4/10
 */
@Controller
public class SearchController {
    @Autowired
    MallSearchService mallSearchService;
    /**
     * @Author fys
     * @Description //根据页面传来数据去es查询数据
     * @Date 2021/4/10
     * @Param
     * @return
    */
    @GetMapping("list.html")
    public String listPage(SearchParam param , Model model){
        SearchResult searchResult=mallSearchService.search(param);
        model.addAttribute("result",searchResult);
        return "list";
    }
}
