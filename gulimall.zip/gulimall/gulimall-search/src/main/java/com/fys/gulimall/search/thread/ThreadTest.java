package com.fys.gulimall.search.thread;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * @Description:
 * @Author : fys
 * @Date : 2021/4/12
 */
public class ThreadTest {
    public static ExecutorService executor=Executors.newFixedThreadPool(10);

    public static void main(String[] args) throws ExecutionException, InterruptedException {
        // 1.没返回值runAsync
        // CompletableFuture<Void> voidCompletableFuture = CompletableFuture.runAsync(() -> {
        //     System.out.println("当前线程"+Thread.currentThread().getId());
        //     int i=10/2;
        //     System.out.println("运行结果"+i);
        // }, executor);

        // 2.有返回值supplyAsync
        // CompletableFuture<Integer> future = CompletableFuture.supplyAsync(() -> {
        //     System.out.println("当前线程"+Thread.currentThread().getId());
        //     int i=10/0;
        //     System.out.println("运行结果"+i);
        //     return i;
        // }, executor).whenComplete((res,exception)->{
        //     // 虽然能得到异常信息，但是没法修改返回数据
        //     System.out.println("结果"+res+";异常是:"+exception);
        // }).exceptionally(throwable -> {
        //     // 可以感知异常，并修改返回值
        //     return 10;
        // });
        // System.out.println( future.get());

        // 3.方法执行完后处理
        // CompletableFuture<Integer> future2 = CompletableFuture.supplyAsync(() -> {
        //     System.out.println("当前线程"+Thread.currentThread().getId());
        //     int i=10/0;
        //     System.out.println("运行结果"+i);
        //     return i;
        // }, executor).handle((res,thread)->{
        //     if(res!=null){
        //         return res*2;
        //     }
        //     if(thread!=null){
        //         return 0;
        //     }
        //     return 0;
        // });
        // // R apply(T t.U u);
        // System.out.println(future2.get());

        /**
         * 4线程出串行化
         * 1.thenRun:不能获取上一步执行结果，但无返回值
         * 2.thenAccept能接受上一步结果，但无返回值
         * 3.thenApply能接受上一步结果，有返回值
         */
        // // 4.1.thenRun:不能获取上一步执行结果
        // CompletableFuture.supplyAsync(() -> {
        //     System.out.println("当前线程"+Thread.currentThread().getId());
        //     int i=10/4;
        //     System.out.println("运行结果"+i);
        //     return i;
        // }, executor).thenRunAsync(()->{
        //     System.out.println("任务二启动");
        // },executor);
        // // 4.2.thenAcceptAsync:能获取上一步执行结果
        // CompletableFuture.supplyAsync(() -> {
        //     System.out.println("当前线程"+Thread.currentThread().getId());
        //     int i=10/4;
        //     System.out.println("运行结果"+i);
        //     return i;
        // }, executor).thenAcceptAsync((res)->{
        //     System.out.println("任务二启动 上一步结果"+res);
        // },executor);
        // // 4.3thenApply能接受上一步结果，有返回值
        // CompletableFuture<Integer> integerCompletableFuture = CompletableFuture.supplyAsync(() -> {
        //     System.out.println("当前线程" + Thread.currentThread().getId());
        //     int i = 10 / 4;
        //     System.out.println("运行结果" + i);
        //     return i;
        // }, executor).thenApplyAsync((res) -> {
        //     System.out.println("任务二启动 上一步结果" + res);
        //     return 10;
        // }, executor);
        // System.out.println(integerCompletableFuture.get());

        /**
         * 5.两个都要完成
         */

        // CompletableFuture<Integer> future1 = CompletableFuture.supplyAsync(() -> {
        //     System.out.println("任务1"+Thread.currentThread().getId());
        //     int i=10/2;
        //     System.out.println("任务1结束"+i);
        //     return i;
        // }, executor);
        //
        // CompletableFuture<Integer> future2 = CompletableFuture.supplyAsync(() -> {
        //     System.out.println("任务2"+Thread.currentThread().getId());
        //     int i=10/2;
        //     System.out.println("任务2结束"+i);
        //     return i;
        // }, executor);
        // 5.1 f1 f2完成后执行，不能获取上一步执行结果，无返回值
        // future1.runAfterBothAsync(future2,()->{
        //     System.out.println("任务3开始");
        // },executor);
        // 5.2 f1 f2完成后执行，能获取上一步执行结果，无返回值
        // future1.thenAcceptBothAsync(future2,(f1,f2)->{
        //     System.out.println("任务3开始:f1="+f1+"  f2="+f2);
        // },executor);
        // 5.3 f1 f2完成后执行，能获取上一步执行结果，有返回值
        // CompletableFuture<Integer> integerCompletableFuture = future1.thenCombineAsync(future2, (f1, f2) -> {
        //     System.out.println("任务3开始:f1=" + f1 + "  f2=" + f2);
        //     return 10;
        // }, executor);
        // System.out.println(integerCompletableFuture.get());

        /**
         * 6.两个一个完成即可
         */
        // CompletableFuture<Integer> future1 = CompletableFuture.supplyAsync(() -> {
        //     System.out.println("任务1"+Thread.currentThread().getId());
        //     int i=10/2;
        //     System.out.println("任务1结束"+i);
        //     return i;
        // }, executor);

        // CompletableFuture<Integer> future2 = CompletableFuture.supplyAsync(() -> {
        //     System.out.println("任务2"+Thread.currentThread().getId());
        //     int i=10/2;
        //     try {
        //         Thread.sleep(1000);
        //     } catch (InterruptedException e) {
        //         e.printStackTrace();
        //     }
        //     System.out.println("任务2结束"+i);
        //     return i;
        // }, executor);
        //6.1两个一个完成就执行3，无返回值
        // future1.runAfterEitherAsync(future2,()->{
        //     System.out.println("3 start");
        // },executor);
        // 6.2两个一个完成就执行,并获取值，无返回值
        // future1.acceptEitherAsync(future2,(res)->{
        //     System.out.println("结果"+res);
        // },executor);
        // 6.3两个一个完成就执行,并获取值，有返回值
        // CompletableFuture<Integer> integerCompletableFuture = future1.applyToEitherAsync(future2, (res) -> {
        //     System.out.println("结果" + res);
        //     return 10;
        // }, executor);
        // System.out.println(integerCompletableFuture.get());


        /**
         * 7多任务组合
         */

        CompletableFuture<String> future1 = CompletableFuture.supplyAsync(() -> {
            System.out.println("查询图片信息");
            return "1.jpeg";
        }, executor);
        CompletableFuture<String> future3 = CompletableFuture.supplyAsync(() -> {
            try {
                Thread.sleep(1000);
                System.out.println("查询属性");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return "黑色+256G";
        }, executor);
        CompletableFuture<String> future2 = CompletableFuture.supplyAsync(() -> {
            System.out.println("查询商品信息");
            return "华为";
        }, executor);
        //7.1所有运行完，才继续执行
        CompletableFuture<Void> allOf = CompletableFuture.allOf(future1, future2, future3);
        //等待所有结果,运行完
        allOf.get();
        System.out.println(future1.get()+"  "+future2.get()+" "+future3.get());

        //7.1所有运行完，才继续执行
        CompletableFuture<Object> anyOf = CompletableFuture.anyOf(future1, future2, future3);
        //一个完成就往下执行
        anyOf.get();
    }
}
