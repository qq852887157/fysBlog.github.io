package com.fys.gulimall.search.config;

import org.apache.http.HttpHost;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestClientBuilder;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @Description: es配置
 * @Author : fys
 * @Date : 2021/4/4
 * 1、导入依赖
 * 2、编写配置，给容器注入一个RestHighLevelClient
 * 3、https://www.elastic.co/guide/en/elasticsearch/client/java-rest/current/java-rest-high-supported-apis.html
 */
@Configuration
public class ElasticSearchConfig {
    public static final RequestOptions COMMON_OPTIONS;
    static {
        RequestOptions.Builder builder=RequestOptions.DEFAULT.toBuilder();
        COMMON_OPTIONS=builder.build();
    }
    @Bean
    public RestHighLevelClient esRestClient(){
        // 1.
        // RestClientBuilder builder = RestClient.builder(new HttpHost("127.0.0.1", 9200, "http"));
        // RestHighLevelClient client=new RestHighLevelClient(builder);

        // 2.
        RestHighLevelClient client=new RestHighLevelClient(
                RestClient.builder(
                        new HttpHost("127.0.0.1",9200,"http")
                )
        );
        return client;
    }


}
