package com.fys.gulimall.search.service;

import com.fys.gulimall.search.vo.SearchParam;
import com.fys.gulimall.search.vo.SearchResult;

/**
 * @Description:商城搜索
 * @Author : fys
 * @Date : 2021/4/10
 */
public interface MallSearchService {
    SearchResult search(SearchParam param);
}
