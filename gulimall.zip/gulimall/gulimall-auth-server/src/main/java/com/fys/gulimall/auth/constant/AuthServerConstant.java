package com.fys.gulimall.auth.constant;

/**
 * @Description:
 * @Author : fys
 * @Date : 2021/4/13
 */
public class AuthServerConstant {
    public static final String SMS_CODE_CACHE_PREFIX = "sms-phone";
}
