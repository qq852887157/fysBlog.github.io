package com.fys.gulimall.auth.fegin;

import com.fys.common.utils.R;
import com.fys.gulimall.auth.vo.UserLoginVo;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @Description:
 * @Author : fys
 * @Date : 2021/4/14
 */
@FeignClient("gulimall-member")
public interface MemberFeignService {
    @RequestMapping("/member/member/login")
    R login(@RequestBody UserLoginVo loginVo);
}
