package com.fys.gulimall.auth.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * @Description:
 * @Author : fys
 * @Date : 2021/4/13
 */
@Configuration
public class WebConfig implements WebMvcConfigurer {
    /**
     * 视图映射
     * @param registry
     */
    @Override
    public void addViewControllers(ViewControllerRegistry registry){
        /**
         * @RequestMapping("/login.html")
         *     public String login(){
         *         return "login";
         *     }
         *
         *     @RequestMapping("/reg.html")
         *     public String reg(){
         *         return "reg";
         *     }
         */
        registry.addViewController("/login.html").setViewName("login");
        registry.addViewController("/reg.html").setViewName("reg");
    }
}
