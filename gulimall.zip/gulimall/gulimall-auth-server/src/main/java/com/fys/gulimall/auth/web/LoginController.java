package com.fys.gulimall.auth.web;

import com.alibaba.fastjson.TypeReference;
import com.fys.common.exception.BizCodeEnum;
import com.fys.common.utils.R;
import com.fys.gulimall.auth.constant.AuthServerConstant;
import com.fys.gulimall.auth.fegin.MemberFeignService;
import com.fys.gulimall.auth.fegin.ThirdPartFeignService;
import com.fys.gulimall.auth.vo.UserLoginVo;
import com.fys.gulimall.auth.vo.UserRegisterVo;
import org.apache.catalina.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

/**
 * @Description:
 * @Author : fys
 * @Date : 2021/4/13
 */
@Controller
public class LoginController {
    // @RequestMapping("/login.html")
    // public String login(){
    //     return "login";
    // }
    //
    // @RequestMapping("/reg.html")
    // public String reg(){
    //     return "reg";
    // }
    @Autowired
    ThirdPartFeignService thirdPartFeignService;
    @Autowired
    StringRedisTemplate stringRedisTemplate;
    @Autowired
    MemberFeignService memberFeignService;
    @GetMapping("/sms/sendCode")
    public R sendCode(@RequestParam("phone")String phone){
        //  接口防刷，redis缓存 sms:code:电话号
        String redisCode = stringRedisTemplate.opsForValue().get(AuthServerConstant.SMS_CODE_CACHE_PREFIX + phone);
        // 如果不为空，返回错误信息
        if(null != redisCode && redisCode.length() > 0){
            long CuuTime = Long.parseLong(redisCode.split("_")[1]);
            if(System.currentTimeMillis() - CuuTime < 60 * 1000){ // 60s
                return R.error(BizCodeEnum.SMS_CODE_EXCEPTION.getCode(), BizCodeEnum.SMS_CODE_EXCEPTION.getMsg());
            }
        }
        // 生成验证码
        String code = UUID.randomUUID().toString().substring(0, 6);
        String redis_code = code + "_" + System.currentTimeMillis();
        // 缓存验证码
        stringRedisTemplate.opsForValue().set(AuthServerConstant.SMS_CODE_CACHE_PREFIX + phone, redis_code , 10, TimeUnit.MINUTES);
        try {// 调用第三方短信服务
            return thirdPartFeignService.sendCode(phone, code);
        } catch (Exception e) {
            // log.warn("远程调用不知名错误 [无需解决]");
        }
        return R.ok();
    }

    @PostMapping("/register")
    public String register(@Valid UserRegisterVo registerVo,
                           BindingResult result,
                           RedirectAttributes attributes) {

        if (result.hasErrors()) {
            return "redirect:http://auth.gulimall.com/reg.html";
        }else {
            return "redirect:http://auth.gulimall.com/login.html";
        }
    }

    @PostMapping("/login")
    public  String login(UserLoginVo vo, HttpSession session){
        //远程登录
        R r = memberFeignService.login(vo);
        if(r.getCode()==0){
            //成功
            session.setAttribute("loginUser",vo);
            return "redirect:http://gulimall.com";
        }else {
            // Map<String,String> errors=new HashMap<>();
            // redirectAttributes.addAllAttributes("errors","账号或密码错误");

            return "redirect:http://auth.gulimall.com/login.html";
        }

    }
    }
