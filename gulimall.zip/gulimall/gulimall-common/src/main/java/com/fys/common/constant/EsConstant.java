package com.fys.common.constant;

/**
 * @Description:
 * @Author : fys
 * @Date : 2021/4/5
 */
public class EsConstant {
    /**
     * sku在es的索引
     */
    public static final  String PRODUCT_INDEX="product";
}
