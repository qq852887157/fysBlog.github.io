package com.fys.common.valid;

/**
 * @Description:
 * @Author : fys
 * @Date : 2021/3/28
 */
public interface AddGroup {
}
