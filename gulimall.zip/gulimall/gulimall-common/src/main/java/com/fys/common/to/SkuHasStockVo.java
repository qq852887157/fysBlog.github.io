package com.fys.common.to;

import lombok.Data;

/**
 * @Description:
 * @Author : fys
 * @Date : 2021/4/4
 */
@Data
public class SkuHasStockVo {
    private Long skuId;
    private Boolean hasStock;
}
