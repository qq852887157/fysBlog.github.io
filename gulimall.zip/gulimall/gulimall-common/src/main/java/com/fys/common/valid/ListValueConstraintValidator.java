package com.fys.common.valid;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.HashSet;
import java.util.Set;

/**
 * @Description: 校验规则类
 * @Author : fys
 * @Date : 2021/3/29
 */
public class ListValueConstraintValidator implements ConstraintValidator<ListValue,Integer> {
    private Set<Integer> set=new HashSet<>();
    //初始化
    @Override
    public void initialize(ListValue constraintAnnotation) {
        //[0,1]
        int[] vals = constraintAnnotation.vals();
        for (int val : vals) {
            set.add(val);
        }
    }
    /**
     * @Author fys
     * @Description //TODO value:需校验 值
     * @Date 2021/3/29
     * @Param
     * @return
    */
    @Override
    public boolean isValid(Integer value, ConstraintValidatorContext constraintValidatorContext) {
        return set.contains(value);
    }
}
