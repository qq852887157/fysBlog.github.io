package com.fys.common.to;

import lombok.Data;

import java.math.BigDecimal;

/**
 * @Description:服务间调用类
 * @Author : fys
 * @Date : 2021/4/3
 */
@Data
public class SpuBoundTo {
    private Long spuId;
    private BigDecimal buyBounds;
    private BigDecimal growBounds;
}
