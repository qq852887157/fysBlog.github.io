package com.fys.gulimall.ware.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.fys.common.utils.PageUtils;
import com.fys.gulimall.ware.entity.WareInfoEntity;

import java.util.Map;

/**
 * 仓库信息
 *
 * @author fys
 * @email fys@gmail.com
 * @date 2021-03-21 20:43:48
 */
public interface WareInfoService extends IService<WareInfoEntity> {

    PageUtils queryPage(Map<String, Object> params);
}

