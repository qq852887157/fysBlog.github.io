package com.fys.gulimall.ware.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.fys.common.utils.PageUtils;
import com.fys.gulimall.ware.entity.WareOrderTaskEntity;

import java.util.Map;

/**
 * 库存工作单
 *
 * @author fys
 * @email fys@gmail.com
 * @date 2021-03-21 20:43:48
 */
public interface WareOrderTaskService extends IService<WareOrderTaskEntity> {

    PageUtils queryPage(Map<String, Object> params);
}

