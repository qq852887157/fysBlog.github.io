package com.fys.gulimall.ware.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.fys.common.utils.PageUtils;
import com.fys.gulimall.ware.Vo.SkuHasStockVo;
import com.fys.gulimall.ware.entity.WareSkuEntity;

import java.util.List;
import java.util.Map;

/**
 * 商品库存
 *
 * @author fys
 * @email fys@gmail.com
 * @date 2021-03-21 20:43:48
 */
public interface WareSkuService extends IService<WareSkuEntity> {

    PageUtils queryPage(Map<String, Object> params);

    List<SkuHasStockVo> getSkuHasStock(List<Long> skuIds);
}

